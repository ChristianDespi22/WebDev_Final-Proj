<?php

// Start the session if not already started
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Check if the user is logged in and the session is valid
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUlogin'] !== true) {
    // If not logged in, redirect to the login page
    header("Location: login.php");
    exit;
}

// Check if the user is a professor or admin
if ($_SESSION['ADUrole'] !== 'professor' && $_SESSION['ADUrole'] !== 'admin') {
    // If the user is neither, show an error message
    echo "You do not have the appropriate role!";
    exit;
}

// Get the professor ID and role from session
$professor_id = $_SESSION['ADUid'];
$user_role = $_SESSION['ADUrole'];

// Include the database connection
include("dbconi.php");

// Get the consultation ID from the URL and sanitize it
$consultation_id = isset($_GET['id']) ? mysqli_real_escape_string($dbc, $_GET['id']) : null;

if ($consultation_id) {
    // Check if consultation_id is numeric to prevent invalid inputs
    if (!is_numeric($consultation_id)) {
        // Redirect if invalid consultation ID
        echo "<script>console.log('Invalid Consultation ID!'); history.back();</script>";
        exit;
    }

    if ($user_role == 'professor') {
        // If the user is a professor, only allow removing students from their own consultations
        $query = "UPDATE consultations 
                  SET student_id = NULL, status = 'open' 
                  WHERE consultation_id = ? 
                  AND professor_id = ?";

        // Prepare the statement
        $stmt = mysqli_prepare($dbc, $query);

        // Bind parameters to the query
        mysqli_stmt_bind_param($stmt, 'ii', $consultation_id, $professor_id);

    } elseif ($user_role == 'admin') {
        // If the user is an admin, they can remove students from any consultation
        $query = "UPDATE consultations 
                  SET student_id = NULL, status = 'open' 
                  WHERE consultation_id = ?";

        // Prepare the statement
        $stmt = mysqli_prepare($dbc, $query);

        // Bind parameters to the query
        mysqli_stmt_bind_param($stmt, 'i', $consultation_id);
    }

    // Execute the query
    $result = mysqli_stmt_execute($stmt);

    // Check if the query was successful
    if ($result && mysqli_affected_rows($dbc) > 0) {
        // Redirect back to the previous page with a success message
        echo "<script>console.log('Student removed successfully!'); history.back();</script>";
        exit;
    } else {
        // If there was an issue, show error message and go back to the previous page
        echo "<script>console.log('Error removing student. Please try again.'); history.back();</script>";
        exit;
    }
} else {
    // Redirect if no consultation ID was provided
    header("Location: view_consultations.php");
    exit;
}

?>
