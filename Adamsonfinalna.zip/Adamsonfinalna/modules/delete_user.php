<?php

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUlogin'] !== true) {
    // Redirect to the login page if not logged in
    header("Location: login.php");
    exit;
}

// Include the database connection
include("dbconi.php");

// Get the user ID to delete from the URL and sanitize it
$user_id = isset($_GET['id']) ? mysqli_real_escape_string($dbc, $_GET['id']) : null;

// Check if the user ID is valid
if (!$user_id || !is_numeric($user_id)) {
    echo '<script>alert("Invalid user ID."); window.location.href="view_users.php";</script>';
    exit;
}

// Check user role and build the query accordingly
if ($_SESSION['ADUrole'] === 'admin') {
    // Admin can delete any user
    $query = "DELETE FROM users WHERE id = '$user_id'";
} else {
    echo '<script>alert("You do not have permission to delete users."); window.location.href="view_users.php";</script>';
    exit;
}

// Execute the query
$result = mysqli_query($dbc, $query);

// Check if the deletion was successful
if ($result && mysqli_affected_rows($dbc) > 0) {
    echo '<script>alert("User successfully deleted."); window.location.href="view_users.php";</script>';
} else {
    echo '<script>alert("Failed to delete user or user does not exist."); window.location.href="view_users.php";</script>';
}

// Close the database connection
mysqli_close($dbc);


