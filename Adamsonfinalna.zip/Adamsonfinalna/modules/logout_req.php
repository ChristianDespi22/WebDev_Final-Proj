<?php
// Start the session if it's not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the POST request is made to log out
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Unset all session variables
    session_unset();

    // Destroy the session
    session_destroy();

    // Redirect to the homepage or login page
    header("Location:../"); 
    exit(); // Ensure that no further code is executed
}
?>

