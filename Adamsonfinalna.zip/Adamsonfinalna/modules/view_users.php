<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('https://www.transparenttextures.com/patterns/stardust.png');
            background-color: #0D1B2A;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .dashboard-container {
            display: flex;
            flex-direction: column;
            background-color: #1B263B;
            border-radius: 15px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            width: 80%;
            max-width: 1200px;
            padding: 40px;
        }

        .dashboard-header {
            margin-bottom: 30px;
        }

        .dashboard-header a {
            background-color: #415A77;
            color: #E0E1DD;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 10px;
            transition: background-color 0.3s ease;
        }

        .dashboard-header a:hover {
            background-color: #778DA9;
        }

        .add-user-btn {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            margin-left: 15px;
            transition: background-color 0.3s ease;
        }

        .add-user-btn:hover {
            background-color: #218838;
        }

        .dashboard-form {
            margin-bottom: 20px;
        }

        .dashboard-form input,
        .dashboard-form select {
            background-color: #ffffff;
            color: #1B263B;
            border: 1px solid #778DA9;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .dashboard-form button {
            background-color: #415A77;
            border: none;
            color: #E0E1DD;
            padding: 10px;
            border-radius: 10px;
            font-size: 16px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .dashboard-form button:hover {
            background-color: #778DA9;
            transform: scale(1.05);
        }

        .table-container {
            background-color: #ffffff;
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
        }

        .table-container .table {
            background-color: #ffffff; /* White background for the table */
            color: #1B263B; /* Dark text color for better contrast */
        }

        .table-container .table th,
        .table-container .table td {
            color: #1B263B; /* Dark text color for table header and cells */
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <div class="dashboard-header">
            <a href="../" class="btn">Back</a>
            <a href="add_user.php" class="add-user-btn">Add User</a>
        </div>
        
        <div class="dashboard-form">
            <form action="?page=view_users" method="get" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>" class="form-control" placeholder="Search by ID or Username">
                </div>
                <div class="col-md-2">
                    <select name="sort_by" class="form-control">
                        <option value="id" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'id' ? 'selected' : ''; ?>>ID</option>
                        <option value="username" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'username' ? 'selected' : ''; ?>>Username</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="order" class="form-control">
                        <option value="ASC" <?php echo isset($_GET['order']) && $_GET['order'] == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                        <option value="DESC" <?php echo isset($_GET['order']) && $_GET['order'] == 'DESC' ? 'selected' : ''; ?>>Descending</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="role" class="form-control">
                        <option value="">All Roles</option>
                        <option value="student" <?php echo isset($_GET['role']) && $_GET['role'] == 'student' ? 'selected' : ''; ?>>Student</option>
                        <option value="professor" <?php echo isset($_GET['role']) && $_GET['role'] == 'professor' ? 'selected' : ''; ?>>Professor</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn">Search</button>
                </div>
            </form>
        </div>

        <div class="table-container">
            <?php
            include("dbconi.php"); // Include the database connection

            $query = "SELECT * FROM users";
            $conditions = [];
            if (isset($_GET['search'])) {
                $search = mysqli_real_escape_string($dbc, $_GET['search']);
                $conditions[] = "(username LIKE '%$search%' OR id LIKE '%$search%')";
            }
            if (isset($_GET['role']) && in_array($_GET['role'], ['student', 'professor'])) {
                $role = mysqli_real_escape_string($dbc, $_GET['role']);
                $conditions[] = "role = '$role'";
            }
            if (count($conditions) > 0) {
                $query .= " WHERE " . implode(" AND ", $conditions);
            }
            $sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'id';
            $order = isset($_GET['order']) ? $_GET['order'] : 'ASC';
            $query .= " ORDER BY $sort_by $order";
            $result = mysqli_query($dbc, $query);

            if (mysqli_num_rows($result) > 0) {
                echo '<table class="table">';
                echo '<thead><tr><th>ID</th><th>Username</th><th>Action</th></tr></thead><tbody>';
                while ($row = mysqli_fetch_array($result)) {
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($row['id']) . '</td>';
                    echo '<td>' . htmlspecialchars($row['username']) . '</td>';
                    echo '<td>';
                    echo '<a href="edit_user.php?id=' . urlencode($row['id']) . '" class="btn btn-primary btn-sm">Edit</a> ';
                    echo '<a href="delete_user.php?id=' . urlencode($row['id']) . '" class="btn btn-danger btn-sm" onclick="return confirm(\'Are you sure you want to delete this user?\');">Delete</a>';
                    echo '</td></tr>';
                }
                echo '</tbody></table>';
            } else {
                echo '<div class="alert alert-warning">No records found!</div>';
            }
            ?>
        </div>
    </div>
</body>
</html>
