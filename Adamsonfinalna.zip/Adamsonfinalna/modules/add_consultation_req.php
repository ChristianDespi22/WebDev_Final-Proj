<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a professor
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUrole'] != 'professor') {
    header("Location: login.php");
    exit;
}

// Get form data
$course_code = $_POST['course_code'];
$recurring_days = isset($_POST['recurring_days']) ? $_POST['recurring_days'] : [];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];
$location = $_POST['location'];
$notes = $_POST['notes'];
$feedback = $_POST['feedback'];

// Get the professor's ID
$professor_id = $_SESSION['ADUid'];

// Connect to the database
include("dbconi.php");

// Fetch semester start and end dates for the course
$query = "SELECT semester_start_date, semester_end_date FROM subject WHERE code = '$course_code'";
$result = mysqli_query($dbc, $query);

if (mysqli_num_rows($result) == 0) {
    echo "<script>alert('Invalid course code!');</script>";
    exit;
}

$row = mysqli_fetch_assoc($result);
$semester_start_date = $row['semester_start_date'];
$semester_end_date = $row['semester_end_date'];

// Ensure recurring_days is selected
if (empty($recurring_days)) {
    echo "<script>alert('Please select at least one recurring day!');</script>";
    echo "<script>window.history.back();</script>";
    exit;
}

// Function to calculate the next occurrence of a selected weekday within the semester range
function calculate_next_weekday($day, $semester_start_date, $semester_end_date) {
    $daysOfWeek = [
        'Monday' => 1,
        'Tuesday' => 2,
        'Wednesday' => 3,
        'Thursday' => 4,
        'Friday' => 5,
        'Saturday' => 6
    ];

    $today = new DateTime();
    $today->modify('next ' . $day); // Get next occurrence of the weekday

    // Loop until we find a valid date within the semester range
    while ($today->format('Y-m-d') < $semester_start_date || $today->format('Y-m-d') > $semester_end_date) {
        $today->modify('next ' . $day);
    }

    return $today->format('Y-m-d');
}

// Generate consultations for the selected recurring days
$consultations_to_add = [];
foreach ($recurring_days as $day) {
    // Calculate the next valid weekday within the semester range
    $consultation_date = calculate_next_weekday($day, $semester_start_date, $semester_end_date);

    // Add consultations to the array, will insert later
    $consultations_to_add[] = [
        'professor_id' => $professor_id,
        'course_code' => $course_code,
        'consultation_date' => $consultation_date,
        'start_time' => $start_time,
        'end_time' => $end_time,
        'location' => $location,
        'notes' => $notes,
        'feedback' => $feedback
    ];

    // Check if there's another week to add, generate more dates within the semester end date
    while (strtotime($consultation_date) <= strtotime($semester_end_date)) {
        $next_week = date('Y-m-d', strtotime('+1 week', strtotime($consultation_date)));
        
        // Only add dates within the semester end date
        if (strtotime($next_week) <= strtotime($semester_end_date)) {
            $consultations_to_add[] = [
                'professor_id' => $professor_id,
                'course_code' => $course_code,
                'consultation_date' => $next_week,
                'start_time' => $start_time,
                'end_time' => $end_time,
                'location' => $location,
                'notes' => $notes,
                'feedback' => $feedback
            ];
        }
        $consultation_date = $next_week;
    }
}

// Insert consultations into the database
foreach ($consultations_to_add as $consultation) {
    $insert_query = "INSERT INTO consultations (professor_id, course_code, consultation_date, start_time, end_time, location, notes, feedback) 
                     VALUES ('" . $consultation['professor_id'] . "', '" . $consultation['course_code'] . "', '" . $consultation['consultation_date'] . "', '" . $consultation['start_time'] . "', '" . $consultation['end_time'] . "', '" . $consultation['location'] . "', '" . $consultation['notes'] . "', '" . $consultation['feedback'] . "')";
    mysqli_query($dbc, $insert_query);
}

// Display alert for what will be inserted into the database (for debugging)
echo "<pre>";
print_r($consultations_to_add);
echo "</pre>";

echo "<script>alert('Consultations added successfully!');</script>";
header("Location: ../");
exit;

?>
