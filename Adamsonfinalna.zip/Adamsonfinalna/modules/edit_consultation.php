<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user ID is passed via URL
if (!isset($_GET['id'])) {
    echo "Consultation ID is missing!";
    exit;
}

// Include the database connection
include('dbconi.php');

// Retrieve the consultation ID from the URL
$consultation_id = $_GET['id'];

// Fetch the consultation data from the database
$query = "SELECT * FROM consultations WHERE consultation_id = ?";
$stmt = mysqli_prepare($dbc, $query);
mysqli_stmt_bind_param($stmt, 'i', $consultation_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// If the consultation is found, display its data in an editable form
if ($row = mysqli_fetch_assoc($result)) {
    $course_code = $row['course_code'];
    $consultation_date = $row['consultation_date'];
    $start_time = $row['start_time'];
    $end_time = $row['end_time'];
    $location = $row['location'];
    $notes = $row['notes'];
} else {
    echo "Consultation not found!";
    exit;
}

// Get the logged-in professor's ID from session
$professor_id = $_SESSION['ADUid']; // Assuming the professor's ID is stored in the session

// Fetch the courses that the professor teaches
$course_query = "SELECT subject.code
                 FROM user_subjects
                 INNER JOIN subject ON user_subjects.subject_id = subject.id
                 WHERE user_subjects.user_id = ? AND user_subjects.role = 'professor'";

$course_stmt = mysqli_prepare($dbc, $course_query);
mysqli_stmt_bind_param($course_stmt, 'i', $professor_id);
mysqli_stmt_execute($course_stmt);
$course_result = mysqli_stmt_get_result($course_stmt);

// Handle form submission to update the consultation data
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_course_code = $_POST['course_code'];
    $new_consultation_date = $_POST['consultation_date'];
    $new_start_time = $_POST['start_time'];
    $new_end_time = $_POST['end_time'];
    $new_location = $_POST['location'];
    $new_notes = $_POST['notes'];

    // Update the consultation data in the database
    $update_query = "UPDATE consultations 
                     SET course_code = ?, consultation_date = ?, start_time = ?, end_time = ?, location = ?, notes = ? 
                     WHERE consultation_id = ?";
    $update_stmt = mysqli_prepare($dbc, $update_query);
    mysqli_stmt_bind_param($update_stmt, 'sssssssi', $new_course_code, $new_consultation_date, $new_start_time, $new_end_time, $new_location, $new_notes, $consultation_id);
    
    if (mysqli_stmt_execute($update_stmt)) {
        echo "Consultation updated successfully!";
        header("Location: professor_dashboard.php");
        exit;
    } else {
        echo "Error updating consultation!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Consultation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
       body {
    background-image: url('https://www.transparenttextures.com/patterns/stardust.png');
    background-color: #0D1B2A;
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.container {
    background-color: #1B263B; /* Keep the container dark for contrast */
    border-radius: 15px;
    padding: 40px;
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
    color: #E0E1DD;
}

.btn {
    background-color: #415A77;
    color: #E0E1DD;
    text-decoration: none;
    padding: 10px 20px;
    border-radius: 10px;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.btn:hover {
    background-color: #778DA9;
    transform: scale(1.05);
}

 .form-select, .form-control {
    color: #000000; /* Change text color to black for contrast */
}

.form-select, .form-control {
    border-radius: 10px;
    border: 1px solid #778DA9;
    background-color: #FFFFFF; /* Set background color of form elements to white */
}

.form-select option {
    color: #000000;
}

.form-select {
    background-color: #FFFFFF;
}

.form-control {
    background-color: #FFFFFF;
}

.btn-secondary {
    background-color: #415A77;
    color: #E0E1DD;
    text-decoration: none;
}

.btn-secondary:hover {
    background-color: #778DA9;
}

h1 {
    color: #E0E1DD;
    text-align: center;
}

label {
    font-weight: bold;
}

    </style>
</head>
<body>
<div class="container mt-4">
    <h1>Edit Consultation</h1>
    <form method="POST" action="">
        <div class="mb-3">
            <label for="course_code" class="form-label">Course Code</label>
            <select class="form-select" id="course_code" name="course_code" required>
                <option value="" disabled>Select a Course</option>
                <?php while ($course_row = mysqli_fetch_assoc($course_result)): ?>
                    <option value="<?php echo $course_row['code']; ?>" <?php echo $course_row['code'] == $course_code ? 'selected' : ''; ?>>
                        <?php echo $course_row['code']; ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="consultation_date" class="form-label">Consultation Date</label>
            <input type="date" class="form-control" id="consultation_date" name="consultation_date" value="<?php echo htmlspecialchars($consultation_date); ?>" required>
        </div>
        <div class="mb-3">
            <label for="start_time" class="form-label">Start Time</label>
            <input type="time" class="form-control" id="start_time" name="start_time" value="<?php echo htmlspecialchars($start_time); ?>" required>
        </div>
        <div class="mb-3">
            <label for="end_time" class="form-label">End Time</label>
            <input type="time" class="form-control" id="end_time" name="end_time" value="<?php echo htmlspecialchars($end_time); ?>" required>
        </div>
        <div class="mb-3">
            <label for="location" class="form-label">Location</label>
            <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($location); ?>" required>
        </div>
        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea class="form-control" id="notes" name="notes" rows="3"><?php echo htmlspecialchars($notes); ?></textarea>
        </div>
        <button type="submit" class="btn">Save Changes</button>
    </form>
    <a href="javascript:history.back()" class="btn btn-secondary mt-3">Cancel</a>
</div>
</body>
</html>
