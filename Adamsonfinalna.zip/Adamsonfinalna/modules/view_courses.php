<?php
include("dbconi.php"); // Include the database connection

// Check if we are editing a course
if (isset($_GET['page']) && $_GET['page'] == 'edit_course' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];

    // Fetch the course details from the database
    $query = "SELECT * FROM subject WHERE id = $id";
    $result = mysqli_query($dbc, $query);
    $course = mysqli_fetch_assoc($result);

    // Check if the course exists
    if (!$course) {
        echo "Course not found.";
        exit();
    }

    // Handle form submission to update the course
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $course_name = mysqli_real_escape_string($dbc, $_POST['course']);
        $course_code = mysqli_real_escape_string($dbc, $_POST['code']);

        // Update the course in the database
        $update_query = "UPDATE subject SET course = '$course_name', code = '$course_code' WHERE id = $id";
        if (mysqli_query($dbc, $update_query)) {
            header("Location: view_courses.php");
            exit();
        } else {
            echo "Error updating course: " . mysqli_error($dbc);
        }
    }
}

if (isset($_GET['page']) && $_GET['page'] == 'delete_course' && isset($_GET['id'])) {
    // Get the course ID from the URL
    $id = (int) $_GET['id'];

    // Prepare a delete query
    $delete_query = "DELETE FROM subject WHERE id = $id";

    // Execute the delete query
    if (mysqli_query($dbc, $delete_query)) {
        // Redirect to the course list page after deletion
        header("Location: view_courses.php");
        exit();
    } else {
        // If deletion fails, show an error message
        echo "Error deleting course: " . mysqli_error($dbc);
    }
}

// Pagination settings
$limit = 10; // Number of results per page
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$offset = ($page - 1) * $limit;

// Initialize the query to fetch all subjects
$query = "SELECT * FROM subject";

// Check for search query
$conditions = [];
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($dbc, $_GET['search']);
    $conditions[] = "(course LIKE '%$search%' OR code LIKE '%$search%')";
}

// Combine all conditions if any
if (count($conditions) > 0) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

// Set the sort column (id, course, or code) and order (ASC or DESC)
$sort_by = isset($_GET['sort_by']) && in_array($_GET['sort_by'], ['id', 'course', 'code']) ? $_GET['sort_by'] : 'id';
$order = isset($_GET['order']) && in_array($_GET['order'], ['ASC', 'DESC']) ? $_GET['order'] : 'ASC';

// Add sorting to the query
$query .= " ORDER BY $sort_by $order LIMIT $limit OFFSET $offset";

$result = mysqli_query($dbc, $query);

// Display the list of courses
?>

<!-- Edit Course Form -->
 
<?php
if (isset($_GET['page']) && $_GET['page'] == 'edit_course' && isset($_GET['id'])): ?>
    <a href="view_courses.php?" class="btn btn-secondary">Back</a>
    <h2>Edit Course</h2>
    <form method="POST">
        <label for="course">Course Name:</label>
        <input type="text" name="course" value="<?php echo htmlspecialchars($course['course']); ?>" required>

        <label for="code">Course Code:</label>
        <input type="text" name="code" value="<?php echo htmlspecialchars($course['code']); ?>" required>

        <button type="submit" class="btn btn-primary">Update Course</button>
    </form>
    

<?php else: ?>
    <!-- Search Form -->
    <a href="../" class="btn btn-secondary">Back</a>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="get">
        <input type="text" name="search" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">

        <!-- Sort Column Dropdown -->
        <select name="sort_by" class="form-control">
            <option value="id" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'id' ? 'selected' : ''; ?>>ID</option>
            <option value="course" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'course' ? 'selected' : ''; ?>>Course</option>
            <option value="code" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'code' ? 'selected' : ''; ?>>Code</option>
        </select>

        <!-- Sort Order Dropdown -->
        <select name="order" class="form-control">
            <option value="ASC" <?php echo isset($_GET['order']) && $_GET['order'] == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
            <option value="DESC" <?php echo isset($_GET['order']) && $_GET['order'] == 'DESC' ? 'selected' : ''; ?>>Descending</option>
        </select>

        <button type="submit" class="btn btn-primary">Search</button>
        <button type="button" class="btn btn-success" onclick="window.location.href='add_course.php'">Add Course</button>
    </form>

    <?php
    if (mysqli_num_rows($result) > 0): ?>
        <table class="table">
            <tr>
                <th>ID</th>
                <th>Course</th>
                <th>Code</th>
                <th>Action</th>
            </tr>
            <?php while ($row = mysqli_fetch_array($result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['id']); ?></td>
                    <td><?php echo htmlspecialchars($row['course']); ?></td>
                    <td><?php echo htmlspecialchars($row['code']); ?></td>
                    <td>
                        <a href="?page=edit_course&id=<?php echo urlencode($row['id']); ?>" class="btn btn-primary">Edit</a>
                        <a href="?page=delete_course&id=<?php echo urlencode($row['id']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this course?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>

        <!-- Pagination Links -->
        <?php
        $count_query = "SELECT COUNT(*) FROM subject";
        if (count($conditions) > 0) {
            $count_query .= " WHERE " . implode(" AND ", $conditions);
        }
        $count_result = mysqli_query($dbc, $count_query);
        $total_records = mysqli_fetch_row($count_result)[0];
        $total_pages = ceil($total_records / $limit);

        if ($total_pages > 1) {
            echo '<div class="pagination">';
            for ($i = 1; $i <= $total_pages; $i++) {
                echo '<a href="?page=view_courses&page_num=' . $i . '" class="btn btn-secondary">' . $i . '</a>';
            }
            echo '</div>';
        }
        ?>
    <?php else: ?>
        <p>No records found!</p>
    <?php endif; ?>
<?php endif; ?>
