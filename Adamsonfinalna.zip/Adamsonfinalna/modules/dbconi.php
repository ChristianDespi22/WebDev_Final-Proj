<?php
// Database connection details
$username = "root";
$password = "";
$server   = "localhost";
$dbasename = "adamson_consultation";

// Establish connection to MySQL server
$dbc = mysqli_connect($server, $username, $password, $dbasename);

// Check if the connection was successful
if (!$dbc) {
    die("Connection failed: " . mysqli_connect_error());
}

// If you want to log connection success (optional)
error_log("Connected to the database successfully!");


?>

