<?php
$isallok = true;
$msg = "";

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check for empty inputs
if (trim($_POST['txtusername']) == '') {
    $isallok = false;
    $msg .= "Enter Username\n";
}
if (trim($_POST['txtpassword']) == '') {
    $isallok = false;
    $msg .= "Enter Password\n";
}

if (!$isallok) {
    echo nl2br($msg);
    exit;
}

include("dbconi.php");

// Escape special characters in user input to prevent SQL injection
$username = mysqli_real_escape_string($dbc, trim($_POST['txtusername']));
$password = mysqli_real_escape_string($dbc, trim($_POST['txtpassword']));

// Prepare the query to fetch user data
$query = "SELECT * FROM users WHERE username = '$username'";
$result = mysqli_query($dbc, $query);

if (!$result) {
    echo "Error in query execution: " . mysqli_error($dbc);
    exit;
}

// Check if user exists
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);

    // Compare password (hashing assumed)
    if (password_verify($password, $row['password'])) {
        // Store user ID in session
        $_SESSION['ADUlogin'] = true;
        $_SESSION['ADUusername'] = $row['username'];
        $_SESSION['ADUid'] = $row['id'];
        $_SESSION['ADUrole'] = $row['role']; // Store role in session

        // Redirect to the dashboard
        echo "<script>window.location.href='../';</script>";
    } else {
        // Invalid password
        echo "<script>alert('Invalid password');</script>";
    }
} else {
    // Username not found
    echo "<script>alert('Username not found');</script>";
}
// Close the database connection
mysqli_close($dbc);
?>

