<?php
include("dbconi.php"); // Include the database connection

// Start the session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect non-admin users to login
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUrole'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Capture and escape search input
$search = mysqli_real_escape_string($dbc, $_GET['search'] ?? '');

// Capture and sanitize sort inputs (using allowed columns and orders)
$allowed_columns = ['professor_name', 'student_name', 'course_code', 'start_time', 'end_time', 'location', 'status'];
$allowed_orders = ['ASC', 'DESC'];

// Default sorting options if not provided
$sort_column = isset($_GET['sort_column']) && in_array($_GET['sort_column'], $allowed_columns) ? $_GET['sort_column'] : 'course_code';
$sort_order = isset($_GET['sort_order']) && in_array($_GET['sort_order'], $allowed_orders) ? $_GET['sort_order'] : 'ASC';

// Build the query with search and sorting
$query = "SELECT 
    consultations.consultation_id AS consultation_id,
    consultations.professor_id,
    professors.username AS professor_name,
    consultations.student_id,
    students.username AS student_name,
    consultations.course_code,
    consultations.start_time,
    consultations.end_time,
    consultations.location,
    consultations.status
FROM consultations
LEFT JOIN users AS professors ON consultations.professor_id = professors.id
LEFT JOIN users AS students ON consultations.student_id = students.id
WHERE (professors.username LIKE '%$search%' OR students.username LIKE '%$search%' OR consultations.course_code LIKE '%$search%' OR consultations.location LIKE '%$search%')
ORDER BY $sort_column $sort_order";

$result = mysqli_query($dbc, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Consultations</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-image: url('https://www.transparenttextures.com/patterns/stardust.png');
        background-color: #0D1B2A;
        font-family: 'Poppins', sans-serif;
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    .container {
        background-color: #1B263B;
        border-radius: 15px;
        padding: 40px;
        box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
        color: #E0E1DD;
    }

    .btn {
        background-color: #415A77;
        color: #E0E1DD;
        text-decoration: none;
        padding: 10px 20px;
        border-radius: 10px;
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .btn:hover {
        background-color: #778DA9;
        transform: scale(1.05);
    }

    .form-select, .form-control {
        color: #1B263B;
    }

    .form-select, .form-control {
        border-radius: 10px;
        border: 1px solid #778DA9;
    }

    option {
        color: #000000; 
        background-color: #ffffff; 
    }

    table {
        background-color: #E0E1DD;
        color: #1B263B;
        border-radius: 10px;
        margin-top: 20px;
    }

    th, td {
        color: #1B263B;
        text-align: center;
        padding: 10px;
    }

    th {
        background-color: #415A77;
        color: #1B263B;
    }

</style>
</head>
<body>
<div class="container">
    <h1 class="text-center mb-4">Admin Consultations</h1>
    <a href="../" class="btn mb-3">Back to Dashboard</a>

    <!-- Search and Sorting Form -->
    <form method="GET" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <label for="search" class="form-label">Search:</label>
                <input type="text" id="search" name="search" class="form-control" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-4">
                <label for="sort_column" class="form-label">Sort By:</label>
                <select id="sort_column" name="sort_column" class="form-select">
                    <option value="professor_name" <?php echo $sort_column == 'professor_name' ? 'selected' : ''; ?>>Professor</option>
                    <option value="student_name" <?php echo $sort_column == 'student_name' ? 'selected' : ''; ?>>Student</option>
                    <option value="course_code" <?php echo $sort_column == 'course_code' ? 'selected' : ''; ?>>Course Code</option>
                    <option value="start_time" <?php echo $sort_column == 'start_time' ? 'selected' : ''; ?>>Start Time</option>
                    <option value="end_time" <?php echo $sort_column == 'end_time' ? 'selected' : ''; ?>>End Time</option>
                    <option value="location" <?php echo $sort_column == 'location' ? 'selected' : ''; ?>>Location</option>
                    <option value="status" <?php echo $sort_column == 'status' ? 'selected' : ''; ?>>Status</option>
                </select>
            </div>
            <div class="col-md-2">
                <label for="sort_order" class="form-label">Order:</label>
                <select id="sort_order" name="sort_order" class="form-select">
                    <option value="ASC" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                    <option value="DESC" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Descending</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn w-100">Apply</button>
            </div>
        </div>
    </form>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Professor</th>
                        <th>Student</th>
                        <th>Course Code</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['professor_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['student_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['course_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['start_time']); ?></td>
                        <td><?php echo htmlspecialchars($row['end_time']); ?></td>
                        <td><?php echo htmlspecialchars($row['location']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <a href="edit_consultation.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-sm">Edit</a>
                            <a href="delete_consultation.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-sm" onclick="return confirm('Are you sure you want to delete this consultation?');">Delete</a>
                            <a href="remove_student.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-sm">Remove Student</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-warning">No consultations found!</p>
    <?php endif; ?>
</div>
</body>
</html>
