<?php
include("dbconi.php");

// Initialize the query to fetch all users
$query = "SELECT * FROM users";

// Filter by search, role, and other criteria
$conditions = [];
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = mysqli_real_escape_string($dbc, $_GET['search']);
    $conditions[] = "(username LIKE '%$search%' OR id LIKE '%$search%')";
}
if (isset($_GET['role']) && in_array($_GET['role'], ['student', 'professor'])) {
    $role = mysqli_real_escape_string($dbc, $_GET['role']);
    $conditions[] = "role = '$role'";
}

// Combine conditions
if (count($conditions) > 0) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

// Sort column and order
$sort_by = isset($_GET['sort_by']) && in_array($_GET['sort_by'], ['id', 'username']) ? $_GET['sort_by'] : 'id';
$order = isset($_GET['order']) && in_array($_GET['order'], ['ASC', 'DESC']) ? $_GET['order'] : 'ASC';
$query .= " ORDER BY $sort_by $order";

$result = mysqli_query($dbc, $query);

// Generate table rows
if (mysqli_num_rows($result) > 0) {
    echo '<table class="table">';
    echo '<tr><th>ID</th><th>Username</th><th>Action</th></tr>';
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['id']) . '</td>';
        echo '<td>' . htmlspecialchars($row['username']) . '</td>';
        echo '<td>
                <a href="edit_user.php?id=' . urlencode($row['id']) . '" class="btn btn-primary">Edit</a>
                <a href="delete_user.php?id=' . urlencode($row['id']) . '" class="btn btn-danger" onclick="return confirm(\'Are you sure you want to delete this user?\');">Delete</a>
              </td>';
        echo '</tr>';
    }
    echo '</table>';
} else {
    echo '<p>No records found!</p>';
}
?>
