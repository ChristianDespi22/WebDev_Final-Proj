<?php
if (isset($_SESSION['ADUlogin']) && $_SESSION['ADUlogin'] == true) {
    header("Location: ../");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('https://www.transparenttextures.com/patterns/stardust.png');
            background-color: #0D1B2A;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            display: flex;
            background-color: #1B263B;
            border-radius: 15px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            width: 60%;
            max-width: 900px;
        }

        .form-section {
            flex: 1;
            padding: 40px;
            color: #E0E1DD;
        }

        .form-section .card-title {
            text-align: center;
            margin-bottom: 30px;
            font-size: 30px;
            font-weight: bold;
            letter-spacing: 1px;
            color: #E0E1DD;
        }

        .form-control {
            background-color: #E0E1DD;
            color: #1B263B;
            border: 1px solid #778DA9;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: box-shadow 0.3s ease, border-color 0.3s ease;
        }

        .form-control:focus {
            box-shadow: 0 0 10px #778DA9;
            border-color: #415A77;
        }

        .btn-primary {
            background-color: #415A77;
            border: none;
            transition: background-color 0.3s ease, transform 0.2s ease;
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            font-size: 16px;
        }

        .btn-primary:hover {
            background-color: #778DA9;
            transform: scale(1.05);
        }

        .image-section {
            flex: 1;
            background: url('./images/aduuu.jpg') no-repeat center center/cover;
        }

        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                width: 90%;
            }

            .image-section {
                height: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Form Section -->
        <div class="form-section">
            <h5 class="card-title">Login</h5>
            <form id="frmlogin" method="POST" action="modules/login_req.php">
                <!-- Username -->
                <div class="form-group">
                    <label for="txtusername">Username</label>
                    <input type="name" class="form-control" id="txtusername" name="txtusername" placeholder="Enter Username" required>
                </div>
                <!-- Password -->
                <div class="form-group">
                    <label for="txtpassword">Password</label>
                    <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter Password" required>
                </div>
                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>

        <!-- Image Section -->
        <div class="image-section"></div>
    </div>
</body>
</html>
