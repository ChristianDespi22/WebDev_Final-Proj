<!-- Navigation -->
<nav class="navbar navbar-expand-lg static-top text-white" style="background-color: #0d1b2a;" id='navbar'>
  <div class="container">
    <!-- Brand with Image and Text -->
    <a class="navbar-brand text-white d-flex align-items-center" href="./">
      <img src="images/adulogo.png" alt="Brand Logo" style="width: 30px; height: 30px; margin-right: 10px;">
      Faculty Members Consultation Appointment
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
        </ul>
      </div>
    </div>
  </nav>
  <style>
    #navbar {
      position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 70px; 
    z-index: 1000; 
    background-color: #0d1b2a; 
    }
    body {
      padding-top: 70px; 
    }
    .nav-link{
      color: white;
    }
  </style>