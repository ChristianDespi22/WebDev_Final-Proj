<?php
session_start();  // Start the session

include("dbconi.php"); // Include the database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize the form data
    $username = mysqli_real_escape_string($dbc, $_POST['username']);
    $password = mysqli_real_escape_string($dbc, $_POST['password']);
    $role = mysqli_real_escape_string($dbc, $_POST['role']);

    // Hash the password before storing it
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert the user into the database
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')";
    if (mysqli_query($dbc, $query)) {
        // Set session message to show success alert
        $_SESSION['success_message'] = "User successfully added!";

        // Redirect back to the user list page after successful insertion
        header("Location: view_users.php");  // Adjusted to direct to the view_users page
        exit;
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #0D1B2A;
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            background-color: #1B263B;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
            color: #E0E1DD;
        }

        h2 {
            color: #E0E1DD;
            text-align: center;
        }

        .form-select, .form-control {
            color: black;
        }

        .form-select, .form-control {
            border-radius: 10px;
            border: 1px solid #778DA9;
            background-color: #FFFFFF;
        }

        .form-select option {
            color: #000000;
        }

        .btn {
            background-color: #415A77;
            color: #E0E1DD;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 10px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        .btn:hover {
            background-color: #778DA9;
            transform: scale(1.05);
        }

        .btn-secondary {
            background-color: #415A77;
            color: #E0E1DD;
            text-decoration: none;
        }


        .alert-success {
            background-color: #4CAF50;
            color: white;
            border-radius: 10px;
            padding: 15px;
            text-align: center;
        }

    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>Add User</h2>
        <form action="add_user.php" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="role" class="form-label">Role:</label>
                <select name="role" id="role" class="form-select" required>
                    <option value="student">Student</option>
                    <option value="professor">Professor</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn">Add User</button>
            <a href="view_users.php" class="btn btn-secondary">Back to User List</a>
        </form>
    </div>

    <!-- Display success message if set -->
    <?php
    if (isset($_SESSION['success_message'])) {
        echo '<div class="alert alert-success mt-3" role="alert">' . $_SESSION['success_message'] . '</div>';
        // Unset the message after it has been displayed
        unset($_SESSION['success_message']);
    }
    ?>
</body>
</html>
