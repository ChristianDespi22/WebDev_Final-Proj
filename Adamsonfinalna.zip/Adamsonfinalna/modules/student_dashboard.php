<?php
// Include the database connection file
include('dbconi.php');

// Get the student ID from the session
$student_id = $_SESSION['ADUid'];

// Escape the user input to prevent SQL injection
$escaped_student_id = mysqli_real_escape_string($dbc, $student_id);

// Create a query to fetch the courses the student is enrolled in along with relevant consultation details
$query = "
SELECT s.course, s.code, c.consultation_id, u.username AS professor_name, c.course_code, c.start_time, c.end_time, c.location, c.notes, c.feedback, c.consultation_date, c.status, c.student_id
FROM user_subjects us
JOIN subject s ON us.subject_id = s.id
LEFT JOIN consultations c ON c.course_code = s.code
LEFT JOIN users u ON c.professor_id = u.id AND u.role = 'professor'
WHERE us.user_id = '$escaped_student_id' AND us.role = 'student';
";
$result = mysqli_query($dbc, $query);
?>
<body>
<div class="row">
    <!-- Sidebar -->
    <div class="col-sm-3 sidebar">
        <div class="text-center">
            <img src="images/profile.png" alt="Profile Picture" style="height: auto; width: 200px; border-radius: 50%; border: 2px solid white; margin-bottom: 10px; margin-top: 20px;">
            <h5 class="profile-name">Welcome, <?php echo $_SESSION['ADUusername']; ?>!</h5>
            <span class="profile-email"><?php echo $_SESSION['ADUrole']; ?></span>
        </div>
        <hr>
        <!-- Logout Button -->
        <form action="modules/logout_req.php" method="post">
            <button type="submit" class="btn btn-logout">
                <img src="images/logouticon.png" alt="Logout" class="btn-icon">
                Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="col-sm-9 content">
        <h3 style="color: #0D1B2A; text-align: center; padding-top: 15px;">
            <strong>Your Enrolled Courses and Consultations</strong>
        </h3>
        <div class="card-container">
            <?php
            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<div class='card'>";
                        echo "<h4>" . htmlspecialchars($row['course']) . "</h4>";
                        echo "<p><strong>Code:</strong> " . htmlspecialchars($row['code']) . "</p>";

                        // Check if there is a consultation related to this course
                        if (!empty($row['consultation_id'])) {
                            echo "<div class='consultation-details'>";
                            echo "<p class='consultation-sub'><strong>Professor:</strong> " . htmlspecialchars($row['professor_name']) . "</p>";
                            echo "<p class='consultation-sub'><strong>Consultation Date:</strong> " . htmlspecialchars($row['consultation_date']) . "</p>";
                            echo "<p class='consultation-sub'><strong>Start Time:</strong> " . htmlspecialchars($row['start_time']) . "</p>";
                            echo "<p class='consultation-sub'><strong>End Time:</strong> " . htmlspecialchars($row['end_time']) . "</p>";
                            echo "<p class='consultation-sub'><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>";

                            // Buttons for canceling or taking slots
                            if ($row['student_id'] == $student_id) {
                                echo "<form method='POST' action='modules/cancel_slot.php'>";
                                echo "<input type='hidden' name='consultation_id' value='" . htmlspecialchars($row['consultation_id']) . "'>";
                                echo "<input type='hidden' name='student_id' value='" . htmlspecialchars($student_id) . "'>";
                                echo "<button type='submit' name='cancel_slot' class='btn btn-cancel'>Cancel Slot</button>";
                                echo "</form>";
                            } else {
                                echo "<form method='POST' action='modules/take_slot.php'>";
                                echo "<input type='hidden' name='consultation_id' value='" . htmlspecialchars($row['consultation_id']) . "'>";
                                echo "<input type='hidden' name='student_id' value='" . htmlspecialchars($student_id) . "'>";
                                echo "<button type='submit' name='take_slot' class='btn btn-take'>Take Slot</button>";
                                echo "</form>";
                            }
                            echo "</div>";
                        } else {
                            echo "<p>No consultations scheduled for this course.</p>";
                        }
                        echo "</div>";
                    }
                } else {
                    echo "<p>You are not enrolled in any courses.</p>";
                }
            } else {
                echo "<p>Error in query execution: " . mysqli_error($dbc) . "</p>";
            }
            ?>
        </div>
    </div>
</div>

<!-- CSS Styles -->
<style>
body {
    background-color: #fff;
    font-family: 'Poppins', sans-serif;
    color: #E0E1DD;
}

.sidebar {
    background-color: #1B263B;
    padding: 20px;
    color: #E0E1DD;
    border-right: 5px solid #fff;
}

.card-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 20px;
    padding: 10px;
}

.card {
    background-color: #1b263b;
    padding: 20px;
    border-radius: 15px;
    width: 500px;
    height: 220px;
    box-sizing: border-box;
    overflow: hidden;
    display: flex;
    flex-direction: column;
    text-align: left;
    transition: transform 0.3s;
    font-size: 12px;
    color: #E0E1DD;
}

.card:hover {
    transform: scale(1.05);
    box-shadow: 0 8px 12px rgba(0, 0, 0, 0.5);
}

.card h4 {
    font-size: 20px;
    margin: 0;
}

.card p {
    font-size: 14px;
    line-height: 1.2;
    word-break: break-word;
}

.btn-logout {
    background-color: transparent;
    color: #fff;
    border: none;
    padding: 20px;
    text-align: left;
    font-size: 20px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    border-radius: 5px;
}

.btn-icon {
    width: 60px;
    height: auto; 
    margin-right: 10px;
    filter: brightness(0) invert(1);
}

.btn:hover {
    opacity: 0.8;
}

.consultation-details {
    font-size: 12px;
    padding-bottom: 5px;
}
p.consultation-sub{
    font-size: 14px;
    padding-top: 0.1px;
    line-height: 0.9;
    
}
.card .btn-cancel, .card .btn-take {
    position: absolute;
    bottom: 20px;
    right: 20px; /* Align buttons to the bottom-right corner */
    background-color: #1B98E0;
    color: white;
    border: none;
    border-radius: 5px;
    padding: 10px 15px;
    font-size: 14px;
    cursor: pointer;
    transition: background-color 0.3s;
}
</style>
</body>
