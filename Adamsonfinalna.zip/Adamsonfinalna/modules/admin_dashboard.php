<?php

// Check if the user is logged in as an admin
if (!isset($_SESSION['ADUrole']) || $_SESSION['ADUrole'] != 'admin') {
    // If not an admin, redirect to login page
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

    <!-- Display -->
    <div class="row">
        <div class='col-sm-3 p-3 text-white' style='background-color: #1b263b; height: 120vh;'>
            <div class='text-center'>
            <img src='images/profile.png' alt='Profile Picture' style='height: auto; width: 200px;border-radius: 50%; border: 2px solid white; margin-bottom: 10px;margin-top: 20px;'>
            <h5 class='profile-name'> Welcome, <?php echo $_SESSION['ADUusername']; ?></h5>
            <span class='profile-email'><?php echo $_SESSION['ADUrole']; ?></span>
            </div>

                <hr class='separator'>
            
                <div class="sidebar">
                <!-- View Users -->
                <form action="modules/view_users.php" method="get">
                    <img src='images/usericon' class='nav-icon'>
                    <button type="submit" class="nav-button">View Users</button>
                </form>
                <!-- View Courses -->
                <form action="modules/view_courses.php" method="get">
                    <img src='images/courseicon' class='nav-icon'>
                    <button type="submit" class="nav-button">View Courses</button>
                </form>
                <!-- View Timetables -->
                <form action="modules/admin_consultations.php" method="get">
                    <img src='images/timetableicon' class='nav-icon'>
                    <button type="submit" class="nav-button">View Timetables</button>
                </form>

                <form action="modules/logout_req.php" method="post">
                <button type="submit" class="nav-button">
                <img src='images/logouticon.png' class='nav-icon'>
                <span class='nav-text'> Logout</span>
                </button>
                </form>

                </div>
        </div>
        <div class='col-sm-9 p-3 text-dark' style='background-color: #e0e1dd; z-index:3;' id='main-content'>
            <div class="container">
                <Center><h2>Annoucements</h2></center>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">

                    <div class="item active">
                        <img src="images/annouce1.jpg" alt="annoucement1" style="width:70%; height:auto;">
                        <div class="carousel-caption">
                        <h3>Final Exam Schedule</h3>
                        <p>Schedule for Final Exam S.Y. 2024-2025 1st Semester</p>
                        </div>
                    </div>

                    <div class="item">
                        <img src="images/annouce2" alt="annoucement2" style="width:70%; height:auto;">
                        <div class="carousel-caption">
                        <h3>Financial Annoucement</h3>
                        <p>Tuition Fee Payment Information</p>
                        </div>
                    </div>
                    
                    <div class="item">
                        <img src="images/annouce3" alt="annoucement3" style="width:70%; height:auto;">
                        <div class="carousel-caption">
                        <h3>Financial Guide for Final Examination</h3>
                        <p>Final Examination Payment Information Details</p>
                        </div>
                    </div>
                
                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">Next</span>
                    </a>
                </div>
                </div>

        </div>
    </div>


    <style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

.separator {
    height: 3px;
    background: #fff; 
}

body{
    font-family: 'Poppins', sans-serif; 
    background-color: #e0e1dd;
}


.sidebar {
            display: flex;
            flex-direction: column;
            padding: 15px;
        }

        

        .sidebar .nav-button {
            background-color: transparent;
            color: #fff;
            border: none;
            padding: 20px;
            text-align: left;
            font-size: 15px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            border-radius: 5px;

        }

        .sidebar .nav-button:hover{
            background-color: #172031;
            color: white;
            border-radius: 8px;
            cursor: pointer;
           
        }


        .sidebar form {
            margin: 25px;
        }

        .nav-icon{
            width: 60px;
            height: auto;
            margin-right: 10px;
            filter: brightness(0) invert(1);
        }

        .carousel-inner{
            color: black;
        }

        .container h2{
            padding: 20px;
        }

        .carousel-inner img {
            max-width: 100%;
            height: auto;
            margin: 0 auto;
        }

        .carousel {
            margin-top: 20px;
        }

        .carousel-caption {
            background: rgba(0, 0, 0, 0.5);
            padding: 15px;
            border-radius: 5px;
        }

        #myCarousel {
            margin:10px;
            margin-right:50px;
        }
</style>

</body>
</html>