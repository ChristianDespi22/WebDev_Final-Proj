<?php
include("dbconi.php"); // Include the database connection

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $id = (int) $_GET['id']; // Sanitize the 'id' to prevent SQL injection

    // Fetch the user details from the database
    $query = "SELECT * FROM users WHERE id = $id";
    $result = mysqli_query($dbc, $query);
    $user = mysqli_fetch_assoc($result);

    // If the user doesn't exist, display an error
    if (!$user) {
        echo "User not found!";
        exit();
    }

    // Handle form submission for updating the user
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = mysqli_real_escape_string($dbc, $_POST['username']);
        $role = mysqli_real_escape_string($dbc, $_POST['role']);
        $password = $_POST['password'];

        // If password is provided, hash it
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $update_query = "UPDATE users SET username = '$username', role = '$role', password = '$hashed_password' WHERE id = $id";
        } else {
            // If no password is provided, just update username and role
            $update_query = "UPDATE users SET username = '$username', role = '$role' WHERE id = $id";
        }

        // Execute the update query
        if (mysqli_query($dbc, $update_query)) {
            echo "<div class='alert alert-success'>User updated successfully!</div>";
            // Redirect to the user list page after successful update
            header("Location: view_users.php");
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error updating user: " . mysqli_error($dbc) . "</div>";
        }
    }

    // Display the edit form with existing data
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit User</title>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            body {
                background-image: url('https://www.transparenttextures.com/patterns/stardust.png');
                background-color: #0D1B2A;
                font-family: 'Poppins', sans-serif;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
            }

            h2{
                color: #E0E1DD;
            }

            .dashboard-container {
                display: flex;
                flex-direction: column;
                background-color: #1B263B;
                border-radius: 15px;
                box-shadow: 0 8px 15px rgba(0, 0, 0, 0.3);
                overflow: hidden;
                width: 80%;
                max-width: 800px;
                padding: 40px;
            }

            .dashboard-header {
                margin-bottom: 30px;
            }

            .dashboard-header a {
                background-color: #415A77;
                color: #E0E1DD;
                text-decoration: none;
                padding: 10px 20px;
                border-radius: 10px;
                transition: background-color 0.3s ease;
            }

            .dashboard-header a:hover {
                background-color: #778DA9;
            }

            .dashboard-form {
                margin-bottom: 20px;
            }

            .dashboard-form input,
            .dashboard-form select {
                background-color: #E0E1DD;
                color: #1B263B;
                border: 1px solid #778DA9;
                border-radius: 10px;
                margin-bottom: 15px;
            }

            .dashboard-form button {
                background-color: #415A77;
                border: none;
                color: #E0E1DD;
                padding: 10px;
                border-radius: 10px;
                font-size: 16px;
                transition: background-color 0.3s ease, transform 0.2s ease;
            }

            .dashboard-form button:hover {
                background-color: #778DA9;
            }

            .form-group label {
                color: #E0E1DD;
            }

            .form-control {
                background-color: #E0E1DD;
                color: #1B263B;
                border-radius: 10px;
                border: 1px solid #778DA9;
            }

            .btn-primary {
                background-color: #415A77;
                color: #E0E1DD;
                border-radius: 10px;
                padding: 10px;
            }

            .btn-secondary {
                background-color: #415A77;
                color: #E0E1DD;
                border-radius: 10px;
                padding: 10px;
                margin-left: 10px;
            }

            .btn-primary:hover, .btn-secondary:hover {
                background-color: #778DA9;
            }

            .form-group {
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
        <div class="dashboard-container">
            <div class="dashboard-header">
                <a href="view_users.php" class="btn btn-secondary">Back to User List</a>
            </div>

            <h2>Edit User</h2>
            <form method="POST" class="dashboard-form">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="role">Role:</label>
                    <select name="role" class="form-control" required>
                        <option value="student" <?php echo $user['role'] == 'student' ? 'selected' : ''; ?>>Student</option>
                        <option value="professor" <?php echo $user['role'] == 'professor' ? 'selected' : ''; ?>>Professor</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" name="password" class="form-control" placeholder="Leave empty if not changing">
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Update User</button>
                    <a href="view_users.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
        
        <!-- Bootstrap JS (Optional) -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
} else {
    echo "<div class='alert alert-danger'>Invalid request!</div>";
}
?>
