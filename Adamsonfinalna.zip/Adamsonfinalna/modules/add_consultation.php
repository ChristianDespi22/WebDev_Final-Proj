<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a professor
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUrole'] != 'professor') {
    header("Location: login.php");
    exit;
}

// Include the database connection file
include("dbconi.php");

// Get the logged-in professor's ID
$professor_id = $_SESSION['ADUid'];

// Fetch course codes taught by the professor
$query = "
    SELECT subject.code
    FROM user_subjects
    INNER JOIN subject ON user_subjects.subject_id = subject.id
    WHERE user_subjects.user_id = ? AND user_subjects.role = 'professor'
";

$stmt = mysqli_prepare($dbc, $query);
mysqli_stmt_bind_param($stmt, 'i', $professor_id); // 'i' for integer
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$courses = [];
while ($row = mysqli_fetch_assoc($result)) {
    $courses[] = $row['code'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Consultation</title>
</head>
<body>
    <h1>Add Consultation</h1>
    <form action="add_consultation_req.php" method="post">
        <!-- Course Code Dropdown -->
        <label for="course_code_dropdown">Course Code (Dropdown):</label>
        <select id="course_code_dropdown" name="course_code" required>
            <option value="" disabled selected>Select a course</option>
            <?php foreach ($courses as $course_code): ?>
                <option value="<?php echo htmlspecialchars($course_code); ?>">
                    <?php echo htmlspecialchars($course_code); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <!-- Recurring Days -->
        <label for="recurring_days">Recurring Days (Select multiple):</label><br>
        <input type="checkbox" name="recurring_days[]" value="Monday"> Monday<br>
        <input type="checkbox" name="recurring_days[]" value="Tuesday"> Tuesday<br>
        <input type="checkbox" name="recurring_days[]" value="Wednesday"> Wednesday<br>
        <input type="checkbox" name="recurring_days[]" value="Thursday"> Thursday<br>
        <input type="checkbox" name="recurring_days[]" value="Friday"> Friday<br>
        <input type="checkbox" name="recurring_days[]" value="Saturday"> Saturday<br><br>

        <!-- Time Inputs -->
        <label for="start_time">Start Time:</label>
        <input type="time" id="start_time" name="start_time" required><br><br>

        <label for="end_time">End Time:</label>
        <input type="time" id="end_time" name="end_time" required><br><br>

        <!-- Location and Notes -->
        <label for="location">Location:</label>
        <input type="text" id="location" name="location"><br><br>

        <label for="notes">Notes:</label><br>
        <textarea id="notes" name="notes"></textarea><br><br>

        <label for="feedback">Feedback:</label><br>
        <textarea id="feedback" name="feedback"></textarea><br><br>

        <!-- Submit Button -->
        <button type="submit">Add Consultation</button>
        <button type="button" onclick="window.location.href='../'">Cancel</button>
    </form>
</body>
</html>
