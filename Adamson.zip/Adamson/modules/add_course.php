<?php
session_start();  // Start the session

include("dbconi.php"); // Include the database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize the form data
    $course_name = mysqli_real_escape_string($dbc, $_POST['course_name']);
    $course_code = mysqli_real_escape_string($dbc, $_POST['course_code']);

    // Insert the course into the database
    $query = "INSERT INTO subject (course, code) VALUES ('$course_name', '$course_code')";
    if (mysqli_query($dbc, $query)) {
        // Set session message to show success alert
        $_SESSION['success_message'] = "Course successfully added!";

        // Redirect back to the course list page after successful insertion
        header("Location: view_courses.php");  // Adjusted to direct to the view_courses page
        exit;
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Add Course</h2>
        <form action="add_course.php" method="POST">
            <div class="mb-3">
                <label for="course_name" class="form-label">Course Name:</label>
                <input type="text" name="course_name" id="course_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="course_code" class="form-label">Course Code:</label>
                <input type="text" name="course_code" id="course_code" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-success">Add Course</button>
            <a href="view_courses.php" class="btn btn-secondary">Back to Course List</a>
        </form>
    </div>

    <!-- Display success message if set -->
    <?php
    if (isset($_SESSION['success_message'])) {
        echo '<div class="alert alert-success mt-3" role="alert">' . $_SESSION['success_message'] . '</div>';
        // Unset the message after it has been displayed
        unset($_SESSION['success_message']);
    }
    ?>
</body>
</html>
