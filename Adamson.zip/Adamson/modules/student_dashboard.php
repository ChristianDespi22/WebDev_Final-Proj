<?php

// Include the database connection file
include('dbconi.php');

// Greet the user with their username and role
echo "Welcome, " . $_SESSION['ADUusername'] . " (ID: " . $_SESSION['ADUid'] . ", Role: " . $_SESSION['ADUrole'] . ")<br>";

// Get the student ID from the session
$student_id = $_SESSION['ADUid']; // User input

// Escape the user input to prevent SQL injection
$escaped_student_id = mysqli_real_escape_string($dbc, $student_id);

// Create a query to fetch the courses the student is enrolled in along with relevant consultation details
$query = "
SELECT s.course, s.code, c.consultation_id, u.username AS professor_name, c.course_code, c.start_time, c.end_time, c.location, c.notes, c.feedback, c.consultation_date, c.status, c.student_id
FROM user_subjects us
JOIN subject s ON us.subject_id = s.id
LEFT JOIN consultations c ON c.course_code = s.code
LEFT JOIN users u ON c.professor_id = u.id AND u.role = 'professor'
WHERE us.user_id = '$escaped_student_id' AND us.role = 'student';
";

// Execute the query for courses and consultations
$result = mysqli_query($dbc, $query);

// Display the courses in cards
echo "<h3>Your Enrolled Courses and Consultations:</h3>";
echo "<div style='display: flex; flex-wrap: wrap;'>";  // This will allow the cards to wrap if needed

// Check if any records are returned
if ($result) {
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Display each course as a card
            echo "<div style='border: 1px solid #ccc; border-radius: 8px; width: 300px; margin: 10px; padding: 10px; box-shadow: 2px 2px 10px rgba(0, 0, 0, 0.1);'>";
            echo "<h4>" . htmlspecialchars($row['course']) . "</h4>";
            echo "<p><strong>Code:</strong> " . htmlspecialchars($row['code']) . "</p>";
            
            // Check if there is a consultation related to this course
            if (!empty($row['consultation_id'])) {
                // Display consultation details inside the course card
                echo "<div style='border-top: 1px solid #ccc; margin-top: 10px; padding-top: 10px;'>";
                echo "<h5>Consultation ID: " . htmlspecialchars($row['consultation_id']) . "</h5>";
                echo "<p><strong>Professor:</strong> " . htmlspecialchars($row['professor_name']) . "</p>";
                echo "<p><strong>Course Code:</strong> " . htmlspecialchars($row['course_code']) . "</p>";
                echo "<p><strong>Consultation Date:</strong> " . htmlspecialchars($row['consultation_date']) . "</p>";
                echo "<p><strong>Start Time:</strong> " . htmlspecialchars($row['start_time']) . "</p>";
                echo "<p><strong>End Time:</strong> " . htmlspecialchars($row['end_time']) . "</p>";
                echo "<p><strong>Status:</strong> " . htmlspecialchars($row['status']) . "</p>";

                // Check if the current student has already taken this slot
                if ($row['student_id'] == $student_id) {
                    // Display the Cancel Slot button if the student is already enrolled
                    echo "<form method='POST' action='modules/cancel_slot.php'>";
                    echo "<input type='hidden' name='consultation_id' value='" . htmlspecialchars($row['consultation_id']) . "'>";
                    echo "<input type='hidden' name='student_id' value='" . htmlspecialchars($student_id) . "'>";
                    echo "<button type='submit' name='cancel_slot' style='padding: 5px 10px; background-color: #FF6347; color: white; border: none; border-radius: 5px;'>Cancel Slot</button>";
                    echo "</form>";
                } else {
                    // Display Take Slot button if the student is not enrolled yet
                    echo "<form method='POST' action='modules/take_slot.php'>";
                    echo "<input type='hidden' name='consultation_id' value='" . htmlspecialchars($row['consultation_id']) . "'>";
                    echo "<input type='hidden' name='student_id' value='" . htmlspecialchars($student_id) . "'>";
                    echo "<button type='submit' name='take_slot' style='padding: 5px 10px; background-color: #4CAF50; color: white; border: none; border-radius: 5px;'>Take Slot</button>";
                    echo "</form>";
                }

                echo "</div>"; // End of consultation details
            } else {
                echo "<p>No consultations scheduled for this course.</p>";
            }

            echo "</div>"; // End of course card
        }
    } else {
        echo "You are not enrolled in any courses.";
    }
} else {
    echo "Error in query execution: " . mysqli_error($dbc);
}

echo "</div>"; // Close the flex container

?>
