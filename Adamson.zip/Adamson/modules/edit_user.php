<?php
include("dbconi.php"); // Include the database connection

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $id = (int) $_GET['id']; // Sanitize the 'id' to prevent SQL injection

    // Fetch the user details from the database
    $query = "SELECT * FROM users WHERE id = $id";
    $result = mysqli_query($dbc, $query);
    $user = mysqli_fetch_assoc($result);

    // If the user doesn't exist, display an error
    if (!$user) {
        echo "User not found!";
        exit();
    }

    // Handle form submission for updating the user
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = mysqli_real_escape_string($dbc, $_POST['username']);
        $role = mysqli_real_escape_string($dbc, $_POST['role']);

        // Update the user's data in the database
        $update_query = "UPDATE users SET username = '$username', role = '$role' WHERE id = $id";
        if (mysqli_query($dbc, $update_query)) {
            echo "User updated successfully!";
            // Redirect to the user list page after successful update
            header("Location: view_users.php");
            exit();
        } else {
            echo "Error updating user: " . mysqli_error($dbc);
        }
    }

    // Display the edit form with existing data
    ?>
    <h2>Edit User</h2>
    <form method="POST">
        <div class="form-group">
            <label for="username">Username:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="role">Role:</label>
            <select name="role" class="form-control" required>
                <option value="student" <?php echo $user['role'] == 'student' ? 'selected' : ''; ?>>Student</option>
                <option value="professor" <?php echo $user['role'] == 'professor' ? 'selected' : ''; ?>>Professor</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update User</button>
    </form>
    <?php
} else {
    echo "Invalid request!";
}
?>
