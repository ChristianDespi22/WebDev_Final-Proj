<?php

include("dbconi.php"); // Include the database connection

// Start the session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Redirect non-admin users to login
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUrole'] != 'admin') {
    header("Location: login.php");
    exit;
}

// Fetch consultations with professor and student usernames
$query = "SELECT 
    consultations.consultation_id AS consultation_id, -- Include the unique ID
    consultations.professor_id,
    professors.username AS professor_name,
    consultations.student_id,
    students.username AS student_name,
    consultations.course_code,
    consultations.start_time,
    consultations.end_time,
    consultations.location,
    consultations.status
FROM consultations
LEFT JOIN users AS professors ON consultations.professor_id = professors.id
LEFT JOIN users AS students ON consultations.student_id = students.id;
";

$result = mysqli_query($dbc, $query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Consultations</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
<div class="container mt-4">
    <h1>Consultations</h1>
    <a href="../" class="btn btn-secondary mb-3">Back to Dashboard</a>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Professor</th>
                        <th>Student</th>
                        <th>Course Code</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['professor_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['student_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['course_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['start_time']); ?></td>
                        <td><?php echo htmlspecialchars($row['end_time']); ?></td>
                        <td><?php echo htmlspecialchars($row['location']); ?></td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <a href="edit_consultation.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="delete_consultation.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this consultation?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p>No consultations found!</p>
    <?php endif; ?>
</div>

</body>
</html>
