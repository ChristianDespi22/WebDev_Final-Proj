<?php
// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a professor
if (!isset($_SESSION['ADUrole']) || $_SESSION['ADUrole'] != 'professor') {
    header("Location: login.php");
    exit;
}

// Include the database connection file
include("dbconi.php");

// Get the logged-in professor's ID
$professor_id = $_SESSION['ADUid'];

// Capture search and sorting inputs
$search = $_GET['search'] ?? ''; // Search term
$sort_column = $_GET['sort_column'] ?? 'consultation_date'; // Sorting column
$sort_order = $_GET['sort_order'] ?? 'ASC'; // Sorting order
$include_past = isset($_GET['include_past']) ? $_GET['include_past'] : '0'; // Checkbox state

// Validate sorting inputs to prevent SQL injection
$allowed_columns = ['id', 'course_code', 'consultation_date', 'location', 'start_time', 'end_time'];
$allowed_orders = ['ASC', 'DESC'];

if (!in_array($sort_column, $allowed_columns)) {
    $sort_column = 'consultation_date'; // Default column
}
if (!in_array($sort_order, $allowed_orders)) {
    $sort_order = 'ASC'; // Default order
}

// Prepare the SQL query with search, sorting, and include_past filter
$query = "SELECT consultations.*, users.username AS student_name
          FROM consultations
          LEFT JOIN users ON consultations.student_id = users.id
          WHERE consultations.professor_id = ? 
          AND (consultations.course_code LIKE ? OR consultations.location LIKE ?)";
          
// If past consultations are not included, add a condition to exclude them
if ($include_past == '0') {
    $query .= " AND consultations.consultation_date >= CURDATE()"; // Only future consultations
}

$query .= " ORDER BY $sort_column $sort_order";

$stmt = mysqli_prepare($dbc, $query);

// Use wildcard search for the search term
$search_term = "%" . $search . "%";
mysqli_stmt_bind_param($stmt, 'iss', $professor_id, $search_term, $search_term);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Function to convert 24-hour format time to 12-hour format with AM/PM
function convertTo12hrFormat($time) {
    $dateTime = DateTime::createFromFormat('H:i:s', $time);  // Format matching "HH:mm:ss"
    if ($dateTime === false) {
        return $time; // Return original time if invalid
    }
    return $dateTime->format('g:i A');  // Convert to 12-hour format with AM/PM
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professor Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> <!-- Bootstrap CSS -->
</head>
<body>
<div class="container mt-4">
    <h1>Welcome to the Professor Dashboard</h1>
    <p>Welcome, <?php echo $_SESSION['ADUusername']; ?> (<?php echo $_SESSION['ADUrole']; ?>)</p>
    <p>Your user ID is <?php echo $_SESSION['ADUid']; ?></p>

    <!-- Add Consultation Button -->
    <a href="modules/add_consultation.php" class="btn btn-primary mb-3">Add New Consultation</a>

    <!-- Search and Sorting Form -->
    <form method="GET" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <label for="search" class="form-label">Search:</label>
                <input type="text" id="search" name="search" class="form-control" value="<?php echo htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-3">
                <label for="sort_column" class="form-label">Sort By:</label>
                <select id="sort_column" name="sort_column" class="form-select">
                    <option value="id" <?php echo $sort_column == 'id' ? 'selected' : ''; ?>>ID</option>
                    <option value="course_code" <?php echo $sort_column == 'course_code' ? 'selected' : ''; ?>>Course</option>
                    <option value="consultation_date" <?php echo $sort_column == 'consultation_date' ? 'selected' : ''; ?>>Date</option>
                    <option value="location" <?php echo $sort_column == 'location' ? 'selected' : ''; ?>>Location</option>
                    <option value="start_time" <?php echo $sort_column == 'start_time' ? 'selected' : ''; ?>>Start Time</option>
                    <option value="end_time" <?php echo $sort_column == 'end_time' ? 'selected' : ''; ?>>End Time</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="sort_order" class="form-label">Order:</label>
                <select id="sort_order" name="sort_order" class="form-select">
                    <option value="ASC" <?php echo $sort_order == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                    <option value="DESC" <?php echo $sort_order == 'DESC' ? 'selected' : ''; ?>>Descending</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Apply</button>
            </div>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="checkbox" id="include_past" name="include_past" value="1" <?php echo isset($_GET['include_past']) ? 'checked' : ''; ?>>
            <label class="form-check-label" for="include_past">
                Include Past Consultations
            </label>
        </div>
    </form>

    <?php
    // Check if there are consultations
    if (mysqli_num_rows($result) > 0) {
        ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Student</th>
                        <th>Course</th>
                        <th>Date</th>
                        <th>Time Range</th>
                        <th>Location</th>
                        <th>Notes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                // Display each consultation
                while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['student_name'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($row['course_code']); ?></td>
                        <td><?php echo htmlspecialchars($row['consultation_date']); ?></td>
                        <td>
                            <?php 
                            // Convert start and end time to 12-hour format with AM/PM
                            $start_time = convertTo12hrFormat($row['start_time']);
                            $end_time = convertTo12hrFormat($row['end_time']);
                            echo htmlspecialchars($start_time) . " - " . htmlspecialchars($end_time);
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['location']); ?></td>
                        <td><?php echo htmlspecialchars($row['notes']); ?></td>
                        <td>
                            <a href="modules/edit_consultation.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="modules/delete_consultation.php?id=<?php echo $row['consultation_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this consultation?');">Delete</a>
                        </td>
                    </tr>
                    <?php
                }
                ?>
                </tbody>
            </table>
        </div>
        <?php
    } else {
        // No consultations found
        echo "<p>No consultations found!</p>";
    }
    ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> <!-- Bootstrap JS -->
</body>
</html>
