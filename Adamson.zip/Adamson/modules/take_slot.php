<?php
// Include the database connection file
include('dbconi.php');

// Check if the consultation_id and student_id are provided
if (isset($_POST['consultation_id']) && !empty($_POST['consultation_id']) && isset($_POST['student_id']) && !empty($_POST['student_id'])) {
    
    // Escape the input to prevent SQL injection
    $consultation_id = mysqli_real_escape_string($dbc, $_POST['consultation_id']);
    $student_id = mysqli_real_escape_string($dbc, $_POST['student_id']);

    // Query to check the current status of the consultation slot
    $query = "
        SELECT status, student_id 
        FROM consultations 
        WHERE consultation_id = '$consultation_id';
    ";

    // Execute the query
    $result = mysqli_query($dbc, $query);

    if ($result) {
        $row = mysqli_fetch_assoc($result);

        // Check if the slot is open (status not 'close' and no student is assigned)
        if ($row) {
            $slot_status = $row['status'];
            $assigned_student_id = $row['student_id'];

            if ($slot_status != 'close' && $assigned_student_id === null) {
                // Slot is open, assign the student to this consultation slot
                $update_query = "
                    UPDATE consultations 
                    SET student_id = '$student_id', status = 'closed' 
                    WHERE consultation_id = '$consultation_id';
                ";

                if (mysqli_query($dbc, $update_query)) {
                    // Success: Notify the user
                    echo "<script>alert('You have successfully taken the consultation slot.');</script>";
                } else {
                    // Error updating the consultation
                    echo "<script>alert('Error: Unable to take the slot. Please try again.');</script>";
                }
            } else {
                // Slot is either closed or already taken
                echo "<script>alert('This consultation slot is either closed or already taken.');</script>";
            }
        } else {
            // Consultation ID not found
            echo "<script>alert('Consultation ID not found.');</script>";
        }
    } else {
        // SQL query failed
        echo "<script>alert('Error in query execution: " . mysqli_error($dbc) . "');</script>";
    }
} else {
    // Missing consultation_id or student_id
    echo "<script>alert('Consultation ID or student ID is missing.');</script>";
}

header("Location: ../");
?>
