<?php
include("dbconi.php"); // Include the database connection

// Check if the 'id' parameter is set and is a valid number
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    // Get the course ID from the URL
    $course_id = mysqli_real_escape_string($dbc, $_GET['id']);

    // Prepare the delete query
    $query = "DELETE FROM subject WHERE id = '$course_id'";

    // Execute the query
    if (mysqli_query($dbc, $query)) {
        // Redirect back to the course list page with a success message
        header("Location: ?page=view_courses&deleted=true");
        exit;
    } else {
        echo "Error deleting record: " . mysqli_error($dbc);
    }
} else {
    echo "Invalid request. Course ID not provided or invalid.";
}
?>
