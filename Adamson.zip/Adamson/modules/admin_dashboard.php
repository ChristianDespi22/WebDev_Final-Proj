<?php

// Check if the user is logged in as an admin
if (!isset($_SESSION['ADUrole']) || $_SESSION['ADUrole'] != 'admin') {
    // If not an admin, redirect to login page
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <p>Welcome, <?php echo $_SESSION['ADUusername']; ?> (<?php echo $_SESSION['ADUrole']; ?>)</p>
    
    <h1>Welcome to the Admin Dashboard</h1>
    <!-- Display -->
    <div class="row">
        <!-- Dashboard buttons -->
        <div class="col-md-6">
            <div class="dashboard-buttons">
                <!-- view user -->
                <form action="modules/view_users.php" method="get">
                    <button type="submit" class="button">View Users</button>
                </form>
                <!-- view courses -->
                <form action="modules/view_courses.php" method="get">
                    <button type="submit" class="button">View Courses</button>
                </form>
                <!-- view timetables -->
                <form action="modules/admin_consultations.php" method="get">
                    <button type="submit" class="button">View Timetables</button>
                </form>
            </div>
        </div>
        <!-- Table -->
        <div class="col-md-6">
            <table class="table" style="width:100%">
                
            </table>
        </div>
    </div>

</body>
</html>
