<?php

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a professor
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUrole'] != 'professor') {
    header("Location: login.php");
    exit;
}

// Include the database connection file
include("dbconi.php");

// Get the consultation ID from the URL
$consultation_id = $_GET['id'] ?? null;

if ($consultation_id) {
    // Prepare the SQL query to remove the student from the consultation
    $query = "UPDATE consultations 
              SET student_id = NULL, status = 'open' 
              WHERE consultation_id = ? AND professor_id = ?";

    $stmt = mysqli_prepare($dbc, $query);

    // Get the professor's ID from session
    $professor_id = $_SESSION['ADUid'];

    // Bind parameters and execute the query
    mysqli_stmt_bind_param($stmt, 'ii', $consultation_id, $professor_id);
    $result = mysqli_stmt_execute($stmt);

    // Check if the query was successful
    if ($result) {
        // Redirect back to the consultations page with a success message
        header("Location: view_consultations.php?status=student_removed");
    } else {
        // Redirect back with an error message if the update failed
        header("Location: view_consultations.php?status=error");
    }
    exit;
} else {
    // Redirect if no consultation ID was provided
    header("Location: view_consultations.php");
    exit;
}

?>
