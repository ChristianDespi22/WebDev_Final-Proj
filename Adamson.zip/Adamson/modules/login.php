<div class="card mx-auto col-md-5 my-3">
  <!-- Login Form -->
    <div class="card-body">
      <h5 class="card-title">Login</h5>
      <form id="frmlogin">
        <!-- Username -->
          <div class="form-group">
              <label for="txtusername">Username ???</label>
              <input type="email" class="form-control" id="txtusername" name="txtusername" aria-describedby="emailHelp" placeholder="Enter Username">
          </div>
        <!-- Password -->
          <div class="form-group">
              <label for="txtpassword">Password</label>
              <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter Password">
          </div>
        <!--  Submit Button -->
          <button type="button" class="btn btn-primary" id="btnlogin">Login</button>
      </form>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("btnlogin").addEventListener("click", function() {
        // Get form data
        const form = document.getElementById("frmlogin");
        const formData = new FormData(form);

        // Create a new XMLHttpRequest to send data via POST
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "modules/login_req.php", true);

        // Handle the response
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = xhr.responseText;
                if (response === 'success') {
                    window.location.href = './'; // Redirect to the home page after success
                } else {
                    alert("Error: " + response); // Show error message
                }
            } else {
                alert("Request failed with status: " + xhr.status);
            }
        };

        // Handle errors
        xhr.onerror = function() {
            alert("Request failed: " + xhr.statusText);
        };

        // Send the request with form data
        xhr.send(formData);
    });
});
</script>

