<div class="card mx-auto col-md-5 my-3">
  <!-- Login Form -->
    <div class="card-body">
      <h5 class="card-title">Login</h5>
      <form id="frmlogin">
        <!-- Username -->
          <div class="form-group">
              <label for="txtusername">Username</label>
              <input type="email" class="form-control" id="txtusername" name="txtusername" aria-describedby="emailHelp" placeholder="Enter Username">
          </div>
        <!-- Password -->
          <div class="form-group">
              <label for="txtpassword">Password</label>
              <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter Password">
          </div>
        <!--  Submit Button -->
          <button type="button" class="btn btn-primary" id="btnlogin">Login</button>
      </form>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("btnlogin").addEventListener("click", function() {
        // Get form data
        const form = document.getElementById("frmlogin");
        const formData = new FormData(form);

        // Create a new XMLHttpRequest to send data via POST
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "modules/login_req.php", true);

        // Handle the response
        xhr.onload = function() {
            if (xhr.status === 200) {
                const response = xhr.responseText;  // Get the plain text response
                if (response === 'success') {
                    // Use setTimeout to refresh the page after a delay (e.g., 1 second)
                    setTimeout(function() {
                        window.location.reload();  // This will refresh the page
                    }, 1000);  // Delay in milliseconds (1000ms = 1 second)
                }
            } else {
                console.log("Request failed with status: " + xhr.status);
            }
        };

        // Send the form data with the request
        xhr.send(formData);  // This sends the form data to the server
    });
});

</script>
