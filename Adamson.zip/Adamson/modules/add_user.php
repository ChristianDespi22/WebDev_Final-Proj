<?php
session_start();  // Start the session

include("dbconi.php"); // Include the database connection

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize the form data
    $username = mysqli_real_escape_string($dbc, $_POST['username']);
    $password = mysqli_real_escape_string($dbc, $_POST['password']);
    $role = mysqli_real_escape_string($dbc, $_POST['role']);

    // Hash the password before storing it
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert the user into the database
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')";
    if (mysqli_query($dbc, $query)) {
        // Set session message to show success alert
        $_SESSION['success_message'] = "User successfully added!";

        // Redirect back to the user list page after successful insertion
        header("Location: view_users.php");  // Adjusted to direct to the view_users page
        exit;
    } else {
        echo "Error: " . mysqli_error($dbc);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Add User</h2>
        <form action="add_user.php" method="POST">
            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password:</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="role" class="form-label">Role:</label>
                <select name="role" id="role" class="form-control" required>
                    <option value="student">Student</option>
                    <option value="professor">Professor</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Add User</button>
            <a href="view_users.php" class="btn btn-secondary">Back to User List</a>
        </form>
    </div>

    <!-- Display success message if set -->
    <?php
    if (isset($_SESSION['success_message'])) {
        echo '<div class="alert alert-success mt-3" role="alert">' . $_SESSION['success_message'] . '</div>';
        // Unset the message after it has been displayed
        unset($_SESSION['success_message']);
    }
    ?>
</body>
</html>
