<?php
$php = "";
// Check if the user is logged in
if (!isset($_SESSION['ADUlogin'])) {
    // User is not logged in, show login form
    include("login.php"); 
} else {
    // User is logged in, show the navigation menu
    include("navigation.php");
}

// Check if 'ADUrole' is set in the session
if (isset($_SESSION['ADUrole'])) {
    if ($_SESSION['ADUrole'] == "admin") {
        // Admin user, show the admin dashboard
        include("admin_dashboard.php");
    } else if ($_SESSION['ADUrole'] == "student") {
        // Student user, redirect to the student dashboard
        header("Location: student_dashboard.php");
        exit; // Always call exit after header to stop further execution
    } else if ($_SESSION['ADUrole'] == "professor") {
        // Professor user, redirect to the professor dashboard
        header("Location: professor_dashboard.php");
        exit; // Always call exit after header to stop further execution
    } else {
        // If the role is not recognized
        echo "Invalid role.";
    }
} else {
    // If 'ADUrole' is not set (i.e., the user is not logged in or role not assigned)
    echo "<script>console.log('No role assigned. Please log in.');</script>";
}



?>
