<?php
// Check if the user is logged in
if (!isset($_SESSION['ADUlogin'])) {
    // Show login form
    include("login.php"); 
} else {
    // Show the navigation menu
    include("navigation.php");
}

// Check if 'ADUrole' is set in the session
if (isset($_SESSION['ADUrole'])) {
    if ($_SESSION['ADUrole'] === "admin") {
        // Show admin dashboard
        include("admin_dashboard.php");
    } elseif ($_SESSION['ADUrole'] === "student") {
        // Redirect to student dashboard
        include("student_dashboard.php");
        exit;
    } elseif ($_SESSION['ADUrole'] === "professor") {
        // Show professor dashboard
        include("professor_dashboard.php");
        exit;
    } else {
        // If the role is not recognized
        echo "Invalid role.";
    }
} else {
    // If 'ADUrole' is not set
    echo "<script>console.log('No role assigned. Please log in.');</script>";
}


