<a href="../" class="btn btn-secondary">Back</a>
<form action="?page=view_users" method="get">
    <input type="text" name="search" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
    
    <!-- Sort Column Dropdown (id or username) -->
    <select name="sort_by" class="form-control">
        <option value="id" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'id' ? 'selected' : ''; ?>>ID</option>
        <option value="username" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] == 'username' ? 'selected' : ''; ?>>Username</option>
    </select>
    
    <!-- Sort Order Dropdown (ASC or DESC) -->
    <select name="order" class="form-control">
        <option value="ASC" <?php echo isset($_GET['order']) && $_GET['order'] == 'ASC' ? 'selected' : ''; ?>>Ascending</option>
        <option value="DESC" <?php echo isset($_GET['order']) && $_GET['order'] == 'DESC' ? 'selected' : ''; ?>>Descending</option>
    </select>
    
    <!-- Role Dropdown (Students or Professors) -->
    <select name="role" class="form-control">
        <option value="">All</option>
        <option value="student" <?php echo isset($_GET['role']) && $_GET['role'] == 'student' ? 'selected' : ''; ?>>Student</option>
        <option value="professor" <?php echo isset($_GET['role']) && $_GET['role'] == 'professor' ? 'selected' : ''; ?>>Professor</option>
    </select>
    <!-- Search -->
    <button type="submit" class="btn btn-primary">Search</button>
    <!-- Add User Button -->
    <button type="button" class="btn btn-success" onclick="window.location.href='add_user.php'">Add User</button>
</form>

<?php
include("dbconi.php"); // Include the database connection

// Initialize the query to fetch all users
$query = "SELECT * FROM users";

// Check for search query
$conditions = [];
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($dbc, $_GET['search']);
    $conditions[] = "(username LIKE '%$search%' OR id LIKE '%$search%')";
}

// Filter by role (students or professors) if selected
if (isset($_GET['role']) && in_array($_GET['role'], ['student', 'professor'])) {
    $role = mysqli_real_escape_string($dbc, $_GET['role']);
    $conditions[] = "role = '$role'";
}

// Combine all conditions if any
if (count($conditions) > 0) {
    $query .= " WHERE " . implode(" AND ", $conditions);
}

// Set the sort column (id or username) and order (ASC or DESC)
$sort_by = isset($_GET['sort_by']) && in_array($_GET['sort_by'], ['id', 'username']) ? $_GET['sort_by'] : 'id';
$order = isset($_GET['order']) && in_array($_GET['order'], ['ASC', 'DESC']) ? $_GET['order'] : 'ASC';

// Add sorting to the query
$query .= " ORDER BY $sort_by $order";

$result = mysqli_query($dbc, $query);

if (mysqli_num_rows($result) > 0) {
    ?>
    <table class="table">
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Action</th>
        </tr>
        
    <?php
    while ($row = mysqli_fetch_array($result)) {
        ?>
        <tr>
            <td><?php echo htmlspecialchars($row['id']); ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td>
            <a href="edit_user.php?id=<?php echo urlencode($row['id']); ?>" class="btn btn-primary">Edit</a>
                <a href="delete_user.php?id=<?php echo urlencode($row['id']); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?');">Delete</a>
            </td>
        </tr>
        <?php
    }
    ?>
    </table>
    <?php
} else {
    echo "No records found!";
}
?>
