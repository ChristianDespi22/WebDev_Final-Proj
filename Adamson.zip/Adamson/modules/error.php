<?php
echo "Page not found! <br />";
echo$page;
echo htmlspecialchars($page);
?>

