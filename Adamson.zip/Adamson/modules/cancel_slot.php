<?php

// Start the session to access session variables
session_start();

// Include the database connection file
include('dbconi.php');

// Check if the form was submitted and the "cancel_slot" button was pressed
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['cancel_slot'])) {
    // Escape special characters in input values
    $consultation_id = mysqli_real_escape_string($dbc, $_POST['consultation_id']);
    $student_id = mysqli_real_escape_string($dbc, $_SESSION['ADUid']); // Logged-in student's ID

    // Check if the student is assigned to this consultation slot
    $check_query = "
        SELECT student_id 
        FROM consultations 
        WHERE consultation_id = '$consultation_id' AND student_id = '$student_id';
    ";
    $check_result = mysqli_query($dbc, $check_query);

    if ($check_result && mysqli_num_rows($check_result) > 0) {
        // If the logged-in student is assigned, proceed to cancel the slot
        $cancel_query = "
    UPDATE consultations
    SET status = 'open', student_id = NULL
    WHERE consultation_id = '$consultation_id' AND student_id = '$student_id';
";


        // Execute the query
        if (mysqli_query($dbc, $cancel_query)) {
            echo "<script>
                alert('You have successfully canceled your consultation slot.');
                window.history.back();
            </script>";
            exit;
        } else {
            echo "<script>
                alert('Error: Unable to cancel the slot. " . mysqli_error($dbc) . "');
                window.history.back();
            </script>";
            exit;
        }
    } else {
        echo "<script>
            alert('You cannot cancel this slot because you are not assigned to it.');
            window.history.back();
        </script>";
        exit;
    }
}
?>
