<?php

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if the user is logged in and is a professor
if (!isset($_SESSION['ADUlogin']) || $_SESSION['ADUrole'] != 'professor') {
    header("Location: login.php");
    exit;
}

// Include the database connection file
include("dbconi.php");

// Get the consultation ID from the query string
$consultation_id = $_GET['id'];

// Prepare the SQL query
$query = "DELETE FROM consultations WHERE consultation_id = ?";

$stmt = mysqli_prepare($dbc, $query);
mysqli_stmt_bind_param($stmt, 'i', $consultation_id);
mysqli_stmt_execute($stmt);

// Redirect to the view consultations page
header("Location: ../");
