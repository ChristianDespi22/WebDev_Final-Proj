<?php
echo "Page not found! <br />";
echo htmlspecialchars($page);
?>

