<?php
// Include the database connection
include("dbconi.php");

// Step 1: Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Step 2: Get the form data and sanitize it
    $id = mysqli_real_escape_string($dbc, $_POST['id']);
    $student_no = mysqli_real_escape_string($dbc, $_POST['student_no']);
    $firstname = mysqli_real_escape_string($dbc, $_POST['firstname']);
    $middlename = mysqli_real_escape_string($dbc, $_POST['middlename']);
    $lastname = mysqli_real_escape_string($dbc, $_POST['lastname']);
    
    // Step 3: Update the database with the new data
    $query = "UPDATE users SET student_no='$student_no', firstname='$firstname', middlename='$middlename', lastname='$lastname' WHERE id='$id'";
    if (mysqli_query($dbc, $query)) {
        // Redirect back to the admin dashboard after update
        echo "<script>window.location.href = '?page=admin_dashboard';</script>";
    } else {
        echo "Error updating record: " . mysqli_error($dbc);
    }
}
?>

<?php
// Step 4: If 'id' is provided, fetch the current user data for that ID
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($dbc, $_GET['id']);
    $query = "SELECT * FROM users WHERE id='$id'";
    $result = mysqli_query($dbc, $query);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "No user found.";
    }
} else {
    echo "No user selected for editing.";
    exit;
}
?>

<!-- Step 5: Display the form for editing -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel">Edit User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="edit_user.php">
                <div class="modal-body">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                    <div class="form-group">
                        <label for="student_no">Student No:</label>
                        <input type="text" class="form-control" id="student_no" name="student_no" value="<?php echo $row['student_no']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="firstname">First Name:</label>
                        <input type="text" class="form-control" id="firstname" name="firstname" value="<?php echo $row['firstname']; ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="middlename">Middle Name:</label>
                        <input type="text" class="form-control" id="middlename" name="middlename" value="<?php echo $row['middlename']; ?>">
                    </div>

                    <div class="form-group">
                        <label for="lastname">Last Name:</label>
                        <input type="text" class="form-control" id="lastname" name="lastname" value="<?php echo $row['lastname']; ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Show the modal on page load if editing
    $(document).ready(function() {
        $('#editModal').modal('show');
    });
</script>
