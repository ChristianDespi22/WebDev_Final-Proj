<?php
echo "Hi Prof";
?>