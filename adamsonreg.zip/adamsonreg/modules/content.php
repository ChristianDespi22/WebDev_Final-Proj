<?php


// Set default page to empty string
$page = "";
if (isset($_GET['page'])) {
    $page = $_GET['page'];
}

// Check if the user is logged in
if (!isset($_SESSION['WDDlogin'])) {
    // User is not logged in, show login form
    include("login.php"); 
} else {
    // User is logged in, show the navigation menu
    include("navigation.php");

    // Role-based redirection or content (Only load dashboard once based on role)
    switch ($_SESSION['WDDrole']) {
        case 'admin':
            include("admin_dashboard.php");
            break;
        case 'student':
            include("student_dashboard.php");
            break;
        case 'professor':
            include("professor_dashboard.php");
            break;
        default:
            // If the role is unrecognized, you can show an error page or default content
            include("error.php");
            break;
    }

    // Handle the page switching based on the URL 'page' parameter
    echo $page . "<br>";  // Debug: Output the page value

    switch ($page) {
        case "": 
            break;
        case "admin_dashboard":
            break;
        case "edit": 
            break;
        case "delete": 
            include("delete.php"); 
            break;
        case "add_user":
            include("add_user.php");
        default: 
            include("error.php");
            break;
    }
}
?>
