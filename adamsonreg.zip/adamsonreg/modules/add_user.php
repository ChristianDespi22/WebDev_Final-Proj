<?php
session_start();

// Check if the user is an admin
if ($_SESSION['WDDrole'] != 'admin') {
    echo "You are not authorized to access this page.";
    exit;
} else {
    include("dbconi.php");

    // Sanitize input
    $username = mysqli_real_escape_string($dbc, $_POST['username']);
    $password = mysqli_real_escape_string($dbc, $_POST['password']);
    $role = mysqli_real_escape_string($dbc, $_POST['role']);

    if (empty($username) || empty($password) || empty($role)) {
        echo "<script>alert('All fields are required!');</script>";
        exit;
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Query to insert the user's data into the database
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashed_password', '$role')";

    if (mysqli_query($dbc, $query)) {
        echo "<script>alert('User added successfully!');</script>";
        echo "<script>window.location.href = '../index.php';</script>";
    } else {
        echo "<script>alert('Error adding user: " . mysqli_error($dbc) . "');</script>";
    }

    mysqli_close($dbc);
}
?>
