<div class="card mx-auto col-md-5 my-3">
  <!-- Login Form -->
    <div class="card-body">
      <h5 class="card-title">Login</h5>
      <form id="frmlogin">
        <!-- Username -->
          <div class="form-group">
              <label for="txtusername">Username ???</label>
              <input type="email" class="form-control" id="txtusername" name="txtusername" aria-describedby="emailHelp" placeholder="Enter Username">
          </div>
        <!-- Password -->
          <div class="form-group">
              <label for="txtpassword">Password</label>
              <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter Password">
          </div>
        <!--  Submit Button -->
          <button type="button" class="btn btn-primary" id="btnlogin">Login</button>
      </form>
    </div>
</div>

<script>
$(document).ready(function(){
	$("#btnlogin").click(function(){
		$.post("modules/login_req.php",$("form#frmlogin").serialize(),function(d){
			if(d=='success'){
				document.location = "./";
			} else {
				alert(d);
			}
		});
	});
});
</script>