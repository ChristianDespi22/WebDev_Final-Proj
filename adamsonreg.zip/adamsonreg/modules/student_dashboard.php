<?php
echo"Hi student";
?>
