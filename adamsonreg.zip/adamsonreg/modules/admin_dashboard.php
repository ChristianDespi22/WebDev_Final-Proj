<?php
/*
 * admin_dashboard.php: This file contains code for the admin dashboard page
 * It displays a list of all users in the database, with options to filter by role and delete records.
 */

// Step 1: Include the database connection
include("dbconi.php");

// Step 2: Prepare the query
$query = "SELECT id, role, username FROM users";

// Step 3: Apply filtering if needed
if (isset($_POST['role']) && $_POST['role'] != '') {
    $query .= " WHERE role = '" . mysqli_real_escape_string($dbc, $_POST['role']) . "'";
}

// Step 4: Execute the query
$result = mysqli_query($dbc, $query);

// Step 5: Display the result
echo "<div style='text-align: center' class='container mt-5'>
<form action='' method='post'>
    <select name='role' id='role' onchange='this.form.submit()'>
        <option value=''>All</option>";
        if (isset($_POST['role']) && $_POST['role'] == 'professor') {
            echo "<option value='professor' selected>Professor</option>";
        } else {
            echo "<option value='professor'>Professor</option>";
        }
        if (isset($_POST['role']) && $_POST['role'] == 'student') {
            echo "<option value='student' selected>Student</option>";
        } else {
            echo "<option value='student'>Student</option>";
        }
        if (isset($_POST['role']) && $_POST['role'] == 'admin') {
            echo "<option value='admin' selected>Admin</option>";
        } else {
            echo "<option value='admin'>Admin</option>";
        }
    echo "</select>
    <button name='delete' type='button' onclick='deleteAlert()'>Delete</button>
    <button type='button' class='btn btn-primary' data-toggle='modal' data-target='#addModal'>Add</button>
    
    <button name='edit' type='button' onclick='editAlert()'>Edit</button>
    
</form>
<script>
    function deleteAlert() {
        var id = prompt('Enter the ID of the record to delete:');
        if (id != null && id !== '') {
            if (confirm('Delete record with ID=' + id + '?')) {
                window.location.href = '?page=admin_dashboard&delete=' + id;
            }
        }
    }

    function editAlert() {
        var id = prompt('Enter the ID of the record to edit:');
        if (id != null && id !== '') {
            // Fetch user data for the given ID and show modal for editing
            window.location.href = '?page=admin_dashboard&edit=' + id;
        }
    }

</script>
<table class='table'>
    <thead>
        <tr>
            <th>ID</th>
            <th>Role</th>
            <th>Username</th>
        </tr>
    </thead>
    <tbody>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>
            <td>" . $row['id'] . "</td>
            <td>" . $row['role'] . "</td>
            <td>" . $row['username'] . "</td>
        </tr>";
    }
    echo "</tbody>
</table>
</div>";

// Handle Edit Record (Fetch and Display Modal)
if (isset($_GET['edit'])) {
    $id = mysqli_real_escape_string($dbc, $_GET['edit']);
    // Query to fetch the user's data
    $query = "SELECT * FROM users WHERE id = '$id'";
    $result = mysqli_query($dbc, $query);
    if ($row = mysqli_fetch_assoc($result)) {
        // Show modal with user data for editing
        echo "
        <div class='modal fade' id='exampleModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
          <div class='modal-dialog' role='document'>
            <div class='modal-content'>
              <div class='modal-header'>
                <h5 class='modal-title' id='exampleModalLabel'>Edit User</h5>
                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                  <span aria-hidden='true'>&times;</span>
                </button>
              </div>
              <div class='modal-body'>
                <form method='POST' action=''>
                  <input type='hidden' name='id' value='" . $row['id'] . "' />
                  <div class='form-group'>
                    <label for='username'>Username:</label>
                    <input type='text' class='form-control' id='username' name='username' value='" . $row['username'] . "' />
                  </div>
                  <div class='form-group'>
                    <label for='role'>Role:</label>
                    <select class='form-control' name='role'>
                      <option value='admin' " . ($row['role'] == 'admin' ? 'selected' : '') . ">Admin</option>
                      <option value='student' " . ($row['role'] == 'student' ? 'selected' : '') . ">Student</option>
                      <option value='professor' " . ($row['role'] == 'professor' ? 'selected' : '') . ">Professor</option>
                    </select>
                  </div>
                  <div class='form-group'>
                    <label for='password'>New Password (Leave empty to keep the current password):</label>
                    <input type='password' class='form-control' id='password' name='password' placeholder='Enter new password' />
                  </div>
                  <button type='submit' class='btn btn-primary'>Save Changes</button>
                </form>
              </div>
            </div>
          </div>
        </div>";
        // Open the modal
        echo "<script>$('#exampleModal').modal('show');</script>";
    }
}

// Handle the POST request after form submission to update the user's data
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $id = mysqli_real_escape_string($dbc, $_POST['id']);
    $username = mysqli_real_escape_string($dbc, $_POST['username']);
    $role = mysqli_real_escape_string($dbc, $_POST['role']);
    $password = mysqli_real_escape_string($dbc, $_POST['password']);

    // If password is provided, hash it
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $updateQuery = "UPDATE users SET username='$username', role='$role', password='$hashed_password' WHERE id='$id'";
    } else {
        $updateQuery = "UPDATE users SET username='$username', role='$role' WHERE id='$id'";
    }

    if (mysqli_query($dbc, $updateQuery)) {
        echo "<script>alert('User updated successfully!');</script>";
        echo "<script>window.location.href = '?page=admin_dashboard';</script>";
    } else {
        echo "<script>alert('Error updating user.');</script>";
    }
}

// Handle Delete Record
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($dbc, $_GET['delete']);
    include("delete.php");
}

// Modal for Add User
echo "<div class='modal fade' id='addModal' tabindex='-1' role='dialog' aria-labelledby='addModalLabel' aria-hidden='true'>
  <div class='modal-dialog' role='document'>
    <div class='modal-content'>
      <div class='modal-header'>
        <h5 class='modal-title' id='addModalLabel'>Add User</h5>
        <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          <span aria-hidden='true'>&times;</span>
        </button>
      </div>
      <form method='POST' action='modules/add_user.php'>
        <div class='modal-body'>
          <div class='form-group'>
            <label for='username'>Username</label>
            <input type='text' class='form-control' id='username' name='username' required>
          </div>
          <div class='form-group'>
            <label for='password'>Password</label>
            <input type='password' class='form-control' id='password' name='password' required>
          </div>
          <div class='form-group'>
            <label for='role'>Role</label>
            <select class='form-control' id='role' name='role' required>
              <option value='admin'>Admin</option>
              <option value='student'>Student</option>
              <option value='professor'>Professor</option>
            </select>
          </div>
        </div>
        <div class='modal-footer'>
          <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
          <button type='submit' class='btn btn-primary'>Add</button>
        </div>
      </form>
    </div>
  </div>
</div>";


