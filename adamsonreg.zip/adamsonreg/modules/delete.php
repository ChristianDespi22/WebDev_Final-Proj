<?php
// Handle Delete Record
if (isset($_GET['delete'])) {
    $id = mysqli_real_escape_string($dbc, $_GET['delete']);
    $query = "DELETE FROM users WHERE id='$id'";
    if (mysqli_query($dbc, $query)) {
        echo "<script>alert('Record deleted successfully.'); window.location.href='?page=admin_dashboard';</script>";
    } else {
        echo "<script>alert('Error deleting record: " . mysqli_error($dbc) . "');</script>";
    }
}