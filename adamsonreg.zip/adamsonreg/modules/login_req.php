<?php
$isallok = true;
$msg = "";

if (trim($_POST['txtusername']) == '') {
    $isallok = false;
    $msg .= "Enter Username\n";
}
if (trim($_POST['txtpassword']) == '') {
    $isallok = false;
    $msg .= "Enter Password\n";
}

if (!$isallok) {
    echo nl2br($msg); // Use nl2br to convert newlines to HTML line breaks
    exit;
}

include("dbconi.php");

// Prepare the query to fetch user data based on username
$query = "SELECT * FROM users WHERE username = ?";
$stmt = $dbc->prepare($query);
$stmt->bind_param("s", $_POST['txtusername']);
$stmt->execute();
$result = $stmt->get_result();

// Check if the query was successful
if (!$result) {
    echo "Error in query execution: " . $dbc->error;
    exit;
}

// Check if user exists
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    // Compare password using password_verify() for hashed password
    if (password_verify($_POST['txtpassword'], $row['password'])) {
        // Start a session and store user data
        session_start();
        $_SESSION['WDDlogin'] = '1';
        $_SESSION['WDDusername'] = $row['username'];
        $_SESSION['WDDrole'] = $row['role']; // Store role in session
        echo "success";
    } else {
        // Invalid password
        echo "Invalid password";
    }
} else {
    // Username not found
    echo "Username not found";
}
?>
