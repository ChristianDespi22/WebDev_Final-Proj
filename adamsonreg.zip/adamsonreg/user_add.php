<?php
// Include the database connection
include("modules/dbconi.php");

// Array of users to add (username, password, role)
$users = [
    ['username' => 'professor1', 'password' => 'password123', 'role' => 'professor'],
    ['username' => 'professor2', 'password' => 'password456', 'role' => 'professor'],
    ['username' => 'student1', 'password' => 'studentpass1', 'role' => 'student'],
    ['username' => 'student2', 'password' => 'studentpass2', 'role' => 'student']
];

// Loop through each user, hash the password, and insert into the database
foreach ($users as $user) {
    $username = mysqli_real_escape_string($dbc, $user['username']);
    $password = password_hash($user['password'], PASSWORD_DEFAULT); // Hash the password
    $role = mysqli_real_escape_string($dbc, $user['role']);

    // SQL query to insert the user
    $query = "INSERT INTO users (username, password, role) VALUES ('$username', '$password', '$role')";

    if (mysqli_query($dbc, $query)) {
        echo "User $username added successfully!<br>";
    } else {
        echo "Error adding user $username: " . mysqli_error($dbc) . "<br>";
    }
}

// Close the database connection
mysqli_close($dbc);
?>
